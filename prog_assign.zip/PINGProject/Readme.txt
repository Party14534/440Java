Zachariah Dellimore V#00980652
To compile the client program run: javac PINGClient.java 
To compile the server program run: javac PINGServer.java
To run the the client program run: java PINGClient <IP> <Port> <ClientID> <Number_of_ping_request_packets> <Wait>
To run the the server program run: java PINGServer <Port> <Loss>